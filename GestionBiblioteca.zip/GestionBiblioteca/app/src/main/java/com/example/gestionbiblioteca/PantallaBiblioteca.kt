package com.example.gestionbiblioteca

import androidx.compose.foundation.indication
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.gestionbiblioteca.ui.BibliotecaViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.gestionbiblioteca.modelo.Genero
import androidx.compose.ui.tooling.preview.Preview
import com.example.gestionbiblioteca.ui.theme.GestionBibliotecaTheme

@Composable
fun PantallaBiblioteca(
    bibliotecaViewModel: BibliotecaViewModel = viewModel(),
    modifier: Modifier
) {
    val uiState by bibliotecaViewModel.uiState.collectAsStateWithLifecycle()


    Column(
        modifier = Modifier.fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text= "Gestion de Biblioteca",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = uiState.titulo,
            onValueChange = {
                bibliotecaViewModel.actualizarTitulo(it)

            },
            label = { Text("Titulo")},
            modifier = Modifier.fillMaxWidth()
        )



        OutlinedTextField(
            value= uiState.autor,
            onValueChange = {
                bibliotecaViewModel.actualizarAutor(it)
            },
            label = {Text("Autor")},
            modifier = Modifier.fillMaxWidth()
        )



        OutlinedTextField(
            value = uiState.isbn,
            onValueChange = {
                bibliotecaViewModel.actualizarIsbn(it)
            },
            label = {Text("ISBN")},
            modifier = Modifier.fillMaxWidth()
        )

    Text(
        text = "Selecciona el genero:"

    )
        Genero.values().forEach { genero ->


            Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically

            ){
                RadioButton(
                    selected = uiState.genero == genero,
                    onClick = {
                        bibliotecaViewModel.actualizarGenero(genero)
                    }
                )

                Text(text =  genero.name)
            }



        }

        Button(
            onClick = {
                bibliotecaViewModel.agregarLibro()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text= "Añadir libro")
        }

        if (uiState.mensajeError.isNotEmpty()) {

            Text(
                text = uiState.mensajeError,
                color = MaterialTheme.colorScheme.error
            )
        }
        Spacer(modifier = Modifier.height(16.dp))


        Text(
            text = "Libros registrados: ${uiState.listaLibros.size}",
            style = MaterialTheme.typography.titleMedium
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            items(uiState.listaLibros) { libro ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    )  {
                        Text(
                            text = libro.titulo,
                            style = MaterialTheme.typography.titleMedium

                        )

                        Text( text = "Autor: ${libro.autor}")

                        Text(text = "ISBN: ${libro.isbn}")

                        Text(text = "Genero: ${libro.genero.name}")
                    }
                }
            }
        }







    }
}


@Preview(showBackground = true)
@Composable
fun BibliotecaPreview() {
    GestionBibliotecaTheme() {
        PantallaBiblioteca(modifier = Modifier)
    }
}
