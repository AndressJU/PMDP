package com.example.gestionbiblioteca.modelo

 enum class Genero {
     NOVELA,
     CIENCIA,
     HISTORIA,
     TECNOLOGIA



}