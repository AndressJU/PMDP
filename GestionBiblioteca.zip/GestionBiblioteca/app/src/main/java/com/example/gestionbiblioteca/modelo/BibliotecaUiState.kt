package com.example.gestionbiblioteca.modelo

data class BibliotecaUiState(

    val listaLibros: List<Libro> = listOf(),


    val titulo: String = "",
    val autor: String="",
    val isbn: String ="",
    val genero: Genero = Genero.NOVELA,

    val mensajeError: String = ""





)
