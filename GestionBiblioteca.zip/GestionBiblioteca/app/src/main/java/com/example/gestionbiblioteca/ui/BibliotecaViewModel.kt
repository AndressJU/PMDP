package com.example.gestionbiblioteca.ui
import androidx.lifecycle.ViewModel
import com.example.gestionbiblioteca.modelo.BibliotecaUiState
import com.example.gestionbiblioteca.modelo.Genero
import com.example.gestionbiblioteca.modelo.Libro
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class BibliotecaViewModel: ViewModel(){

    private val _uiState = MutableStateFlow(BibliotecaUiState())

    val uiState: StateFlow<BibliotecaUiState> = _uiState.asStateFlow()


    fun actualizarTitulo(titulo:String) {
        _uiState.update {
            it.copy(titulo = titulo)
        }
    }


    fun actualizarAutor(autor : String) {
        _uiState.update {
            it.copy(autor = autor)
        }
    }

    fun actualizarIsbn(isbn : String ){
        _uiState.update {
            it.copy(isbn = isbn)
        }
    }

    fun actualizarGenero(genero : Genero) {
        _uiState.update {
           it.copy(genero = genero)
        }
    }

    fun agregarLibro() {
        val estado = _uiState.value

        if(estado.isbn.isNotBlank()) {

            val nuevoLibro= Libro(
                titulo = estado.titulo,
                autor = estado.autor,
                isbn = estado.isbn,
                genero = estado.genero
            )


            _uiState.update {
                it.copy(
                    listaLibros = it.listaLibros + nuevoLibro,
                    mensajeError = ""
                )
            }
            limpiarFormulario()

        }else{
            _uiState.update {
                it.copy(mensajeError = "El ISBN es obligatorio")
            }
        }
    }

    fun limpiarFormulario(){
        _uiState.update {
            it.copy(
                titulo = "",
                autor ="",
                isbn = "",
                genero = Genero.NOVELA,
                mensajeError = ""

            )

        }
        }


    }
