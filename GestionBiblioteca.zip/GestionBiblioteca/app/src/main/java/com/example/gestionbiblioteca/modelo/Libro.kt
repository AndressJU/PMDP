package com.example.gestionbiblioteca.modelo

data class Libro (
    val titulo: String,
    val autor: String,
    val isbn: String,
    val genero: Genero

)
