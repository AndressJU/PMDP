package com.example.ud4_ejemplo2.modelo

data class OperacionUIState(
    val numero1: String = "",
    val numero2: String = "",
    val numero3: String = "",

    val resultado: String = "",
    val resultadoM: String = ""

)
