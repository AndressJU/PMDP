package com.example.ejerciciotareas.modelos

data class TareasUiState(




)
