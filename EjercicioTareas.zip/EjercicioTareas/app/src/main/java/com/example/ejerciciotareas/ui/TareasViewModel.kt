package com.example.ejerciciotareas.ui

class TareasViewModel {
}