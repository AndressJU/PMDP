package com.example.ejerciciotareas.modelos

data class Tarea(
    val titulo: String = "",
    val descripcion: String = ""

    )
