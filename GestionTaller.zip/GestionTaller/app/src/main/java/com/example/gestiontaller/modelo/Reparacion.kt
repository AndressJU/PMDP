package com.example.gestiontaller.modelo

data class Reparacion (

    val matricula: String,
    val averias: String,
    val precio: Double,
    val tipo: TipoVehiculo,
    val esUrgente: Boolean,
    val codigoOrden: String

)
