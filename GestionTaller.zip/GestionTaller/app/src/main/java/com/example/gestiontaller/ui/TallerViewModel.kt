package com.example.gestiontaller.ui

import androidx.lifecycle.ViewModel
import com.example.gestiontaller.modelo.Reparacion
import com.example.gestiontaller.modelo.TallerUiState
import com.example.gestiontaller.modelo.TipoVehiculo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class TallerViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(TallerUiState())
    val uiState: StateFlow<TallerUiState> = _uiState.asStateFlow()

    fun actualizarMatricula(matricula: String) {
        _uiState.update { it.copy(matricula = matricula, mostrarError = false) }
    }

    fun actualizarAverias(averias: String) {
        _uiState.update { it.copy(averias = averias, mostrarError = false) }
    }

    fun actualizarPrecio(precio: String) {
        _uiState.update { it.copy(precio = precio, mostrarError = false) }
    }

    fun actualizarTipo(tipo: TipoVehiculo) {
        _uiState.update { it.copy(tipo = tipo) }
    }

    fun actualizarUrgencia(esUrgente: Boolean) {
        _uiState.update { it.copy(esUrgente = esUrgente) }
    }

    fun agregarReparacion() {
        val estado = _uiState.value
        val precioNumerico = estado.precio.toDoubleOrNull()

        // 1. Validación completa con OR (||) y return para frenar si hay error
        if (estado.matricula.isBlank() ||
            estado.averias.isBlank() ||
            precioNumerico == null ||
            precioNumerico <= 0.0
        ) {
            _uiState.update { it.copy(mostrarError = true) }
            return
        }

        // 2. Generar código en una variable local (no modificando el estado)
        val letras3 = estado.averias.take(3).uppercase()
        val matricula4 = estado.matricula.take(4).uppercase()
        val codigoGenerado = letras3 + matricula4

        // 3. Crear el objeto Reparacion con el precio ya convertido a Double
        val nuevaReparacion = Reparacion(
            matricula = estado.matricula,
            averias = estado.averias,
            precio = precioNumerico,
            tipo = estado.tipo,
            esUrgente = estado.esUrgente,
            codigoOrden = codigoGenerado
        )

        // 4. Añadir a la lista y limpiar campos
        _uiState.update {
            it.copy(
                listaReparaciones = it.listaReparaciones + nuevaReparacion,
                mostrarError = false
            )
        }
        limpiarReparaciones()
    }

    fun limpiarReparaciones() {
        _uiState.update {
            it.copy(
                matricula = "",
                averias = "",
                precio = "",
                tipo = TipoVehiculo.COCHE,
                esUrgente = false,
                mostrarError = false
            )
        }
    }
}