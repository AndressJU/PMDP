package com.example.gestiontaller.modelo

data class TallerUiState(
    val listaReparaciones: List<Reparacion> = listOf(),
    val matricula: String = "",
    val averias: String = "",
    val precio: String ="",
    val tipo: TipoVehiculo = TipoVehiculo.COCHE,
    val esUrgente: Boolean = false,
    val mostrarError: Boolean= false,
    var codigoOrden: String =""



)
