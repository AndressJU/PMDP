package com.example.gestiontaller

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.gestiontaller.modelo.Reparacion
import com.example.gestiontaller.modelo.TipoVehiculo
import com.example.gestiontaller.ui.TallerViewModel
import com.example.gestiontaller.ui.theme.GestionTallerTheme

@Composable
fun PantallaTaller(
    TallerViewModel: TallerViewModel = viewModel(),
    modifier : Modifier

){
    val uiState by TallerViewModel.uiState.collectAsState()



    Column(
        modifier = Modifier.fillMaxSize()
            .padding(16.dp)
    ){
        Text(text="Gestion de Taller",
        style = MaterialTheme.typography.titleMedium
        )


        Row( modifier = Modifier.fillMaxWidth()) {

            OutlinedTextField(
                isError = uiState.mostrarError,
                value = uiState.matricula,
                onValueChange = {
                    TallerViewModel.actualizarMatricula(it)
                },
                label = {Text("Matricula:")},
                modifier = Modifier.weight(0.4f)
            )



            Spacer(modifier = Modifier.weight(0.1f))


            OutlinedTextField(
                value = uiState.averias,
                onValueChange = {
                    TallerViewModel.actualizarAverias(it)
                },
                label = {Text("Averias:")},
                modifier = Modifier.weight(0.4f)

            )
        }

        Spacer(modifier = Modifier.padding(16.dp))


        Text(text = "Precio:")
        OutlinedTextField(
            isError = uiState.mostrarError,
            value = uiState.precio,
            onValueChange = {
                TallerViewModel.actualizarPrecio(it)
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )

        Text(text = "Tipo:")

        TipoVehiculo.values().forEach { tipoVehiculo ->

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically){
                RadioButton(
                    selected = uiState.tipo == tipoVehiculo,
                    onClick = { TallerViewModel.actualizarTipo(tipoVehiculo) }

                )

                Text(text = tipoVehiculo.name)







            }



        }

        Spacer( modifier = Modifier.padding(16.dp))
        Row( verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(text = "¿Es urgente?")
            Spacer(modifier = Modifier.weight(1f))
            Switch(
                checked = uiState.esUrgente,
                onCheckedChange = { TallerViewModel.actualizarUrgencia(it)}
            )
        }

        Button(modifier = Modifier.fillMaxWidth(),
            onClick = { TallerViewModel.agregarReparacion() }
            ) {
            Text(text = "Agregar Reparacion")
        }




        HorizontalDivider( modifier = Modifier.padding(vertical = 16.dp))
           var listaReparacionesTamaño = uiState.listaReparaciones.size

        Text( text = "Lista de Reparaciones")
        Text(text = "Total Reparaciones: "+ listaReparacionesTamaño)
// 1. Separamos la lista en dos sublistas
        val normales = uiState.listaReparaciones.filter { !it.esUrgente }
        val urgentes = uiState.listaReparaciones.filter { it.esUrgente }

        // 2. Dos columnas paralelas con LazyColumn
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // COLUMNA IZQUIERDA: NORMALES
            Column(modifier = Modifier.weight(1f)) {

                Spacer(modifier = Modifier.height(4.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(normales) { reparacion ->
                        TarjetaReparacion(reparacion = reparacion)
                    }
                }
            }

            // COLUMNA DERECHA: URGENTES
            Column(modifier = Modifier.weight(1f)) {

                Spacer(modifier = Modifier.height(4.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(urgentes) { reparacion ->
                        TarjetaReparacion(reparacion = reparacion)
                    }
                }
            }
        }
    }
}

@Composable
fun TarjetaReparacion(reparacion: Reparacion) {
    // 3. Color rojo suave si es urgente, color normal si no lo es
    val colorFondo = if (reparacion.esUrgente) {
        Color.Red.copy(alpha = 0.15f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = colorFondo),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = reparacion.codigoOrden,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(text = "Matrícula: ${reparacion.matricula}", style = MaterialTheme.typography.bodySmall)
            Text(text = "Avería: ${reparacion.averias}", style = MaterialTheme.typography.bodySmall)
            Text(text = "Precio: ${reparacion.precio} €", style = MaterialTheme.typography.bodySmall)
            Text(text = "Tipo: ${reparacion.tipo.name}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    GestionTallerTheme {
        PantallaTaller(modifier = Modifier)
    }
}