package com.example.gestiontaller.modelo

enum class TipoVehiculo{

    COCHE,
    MOTO,
    FURGONETA

}



