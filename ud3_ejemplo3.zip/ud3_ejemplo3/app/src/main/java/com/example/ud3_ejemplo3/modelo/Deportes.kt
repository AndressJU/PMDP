package com.example.ud3_ejemplo3.modelo

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
data class Deportes(
    @StringRes val stringResourceId: Int,
    @DrawableRes val imagenResourceId: Int
)

