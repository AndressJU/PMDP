package com.example.ud3_ejemplo2.datos


import com.example.ud3_ejemplo2.R
import com.example.ud3_ejemplo2.modelo.Deportes
class Datos {




    fun cargarDeportes(): List<Deportes> = listOf(

        Deportes(R.string.deporte1, R.drawable.deporte1),
        Deportes(R.string.deporte2, R.drawable.deporte2),
        Deportes(R.string.deporte3, R.drawable.deporte3_),
        Deportes(R.string.deporte4, R.drawable.deporte4),
        Deportes(R.string.deporte5, R.drawable.deporte5),


        )




}


