package com.example.ud3_ejemplo2

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.ud3_ejemplo2.datos.Datos
import com.example.ud3_ejemplo2.modelo.Deportes
import com.example.ud3_ejemplo2.ui.theme.Ud3_ejemplo2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Ud3_ejemplo2Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    ud3Ejemplo2App(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun ud3Ejemplo2App(modifier:Modifier = Modifier) {

    ListaDeportes(
        lista = Datos().cargarDeportes(),
        modifier= modifier
    )


}

@Composable
fun ListaDeportes(lista: List<Deportes>, modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier) {
        items(lista) { deporte ->
            TarjetaDeporte(
                deporte = deporte,
                modifier = Modifier.padding(8.dp),
                onTarjetaClick = { tarjetaElegida ->
                    Log.v(
                        "Tarjeta pulsada",
                        tarjetaElegida.stringResourceId.toString()
                    )
                }
            )
        }
    }
}
@Composable
fun ItemDeporte(deporte: Deportes, onTarjetaClick: (Deportes) -> Unit) {

    TarjetaDeporte(
        deporte = deporte,
        modifier = Modifier.padding(8.dp),
        onTarjetaClick = {
            onTarjetaClick(deporte)
        }
    )
}










@Composable
fun TarjetaDeporte(
    deporte: Deportes,
    modifier: Modifier = Modifier,
    onTarjetaClick: (Deportes) -> Unit
) {
    Card(
        modifier = modifier.clickable {
            onTarjetaClick(deporte)
        }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(deporte.imagenResourceId),
                contentDescription = stringResource(deporte.stringResourceId)
            )

            Text(
                text = stringResource(deporte.stringResourceId),
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.headlineSmall
            )
        }
    }
}


