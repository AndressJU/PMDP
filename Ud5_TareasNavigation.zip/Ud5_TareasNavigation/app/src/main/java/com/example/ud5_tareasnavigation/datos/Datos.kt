package com.example.ud5_tareasnavigation.datos

val listaModulos = listOf("AD", "DI", "PMDM")